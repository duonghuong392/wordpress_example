<?php
/**
 * @package Punte
 */
?>

<div id="secondary-left" class="widget-area sidebar">
    <?php dynamic_sidebar( 'sidebar-left' ); ?>
</div><!-- #secondary -->

<div id="secondary-right" class="widget-area sidebar">
    <?php dynamic_sidebar( 'sidebar-right' ); ?>
</div><!-- #secondary -->